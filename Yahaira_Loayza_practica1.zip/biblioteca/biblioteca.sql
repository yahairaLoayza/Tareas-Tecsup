CREATE DATABASE biblioteca;

CREATE TABLE IF NOT EXISTS Libros (
    Libro_ID SERIAL PRIMARY KEY,
    Titulo VARCHAR(255) NOT NULL
);

CREATE TABLE IF NOT EXISTS Autores (
    Autor_ID SERIAL PRIMARY KEY,
    Nombre VARCHAR(255) NOT NULL
);

CREATE TABLE IF NOT EXISTS Categorias (
    Categoria_ID SERIAL PRIMARY KEY,
    Nombre VARCHAR(255) NOT NULL
);

CREATE TABLE IF NOT EXISTS Lectores (
    Lector_ID SERIAL PRIMARY KEY,
    Nombre VARCHAR(255) NOT NULL
);

CREATE TABLE IF NOT EXISTS Prestamos (
    Prestamo_ID SERIAL PRIMARY KEY,
    Libro_ID INT NOT NULL,
    Lector_ID INT NOT NULL,
    Fecha_Prestamo DATE NOT NULL,
    Fecha_Devolucion_Esperada DATE NOT NULL,

    FOREIGN KEY (Libro_ID) REFERENCES Libros(Libro_ID),
    FOREIGN KEY (Lector_ID) REFERENCES Lectores(Lector_ID)
);

CREATE TABLE IF NOT EXISTS Autores_Libros (
    Autor_ID INT NOT NULL,
    Libro_ID INT NOT NULL,
    PRIMARY KEY (Autor_ID, Libro_ID),

    FOREIGN KEY (Autor_ID) REFERENCES Autores(Autor_ID) ON DELETE CASCADE,
    FOREIGN KEY (Libro_ID) REFERENCES Libros(Libro_ID) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS Libros_Categorias (
    Libro_ID INT NOT NULL,
    Categoria_ID INT NOT NULL,
    PRIMARY KEY (Libro_ID, Categoria_ID),

    FOREIGN KEY (Libro_ID) REFERENCES Libros(Libro_ID) ON DELETE CASCADE,
    FOREIGN KEY (Categoria_ID) REFERENCES Categorias(Categoria_ID) ON DELETE CASCADE
);


INSERT INTO Libros (Titulo) VALUES 
('El principito'), 
('1984'), 
('Cien años de soledad'), 
('Moby Dick'), 
('Don Quijote');


INSERT INTO Autores (Nombre) VALUES
 ('Antoine de Saint-Exupéry'), 
 ('George Orwell'), 
 ('Gabriel García Márquez'), 
 ('Herman Melville'), 
 ('Miguel de Cervantes');


INSERT INTO Categorias (Nombre) VALUES 
('Ficción'),
('Ciencia Ficción'), 
('Realismo Mágico'),
('Aventura'),
('Clásico');


INSERT INTO Lectores (Nombre) VALUES 
('Juan Pérez'), 
('María López'), 
('Carlos Rodríguez'), 
('Ana Gómez'), 
('Luis Fernández');



INSERT INTO Prestamos (Libro_ID, Lector_ID, Fecha_Prestamo, Fecha_Devolucion_Esperada) VALUES 
(1, 1, '2024-03-01', '2024-03-15'),
(2, 2, '2024-03-02', '2024-03-16'),
(3, 3, '2024-03-03', '2024-03-17'),
(4, 4, '2024-03-04', '2024-03-18'),
(5, 5, '2024-03-05', '2024-03-19');


INSERT INTO Autores_Libros (Autor_ID, Libro_ID) VALUES 
(1, 1),
(2, 2),
(3, 3),
(4, 4),
(5, 5);


INSERT INTO Libros_Categorias (Libro_ID, Categoria_ID) VALUES 
(1, 1),
(2, 2),
(3, 3),
(4, 4),
(5, 5);


DELETE FROM orders WHERE order_id = 1;

SELECT * FROM Libros;
SELECT * FROM Autores;
SELECT * FROM Categorias;
SELECT * FROM Lectores;
SELECT * FROM Prestamos;
SELECT * FROM Autores_Libros;
SELECT * FROM Libros_Categorias;

